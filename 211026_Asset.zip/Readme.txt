(대충 햄스터가 '읽어줘요'하는 짤)

1, 미니언(21 10 26 버전)

1.1, 구성
Prefab 형식의 미니언
미니언 3종: 근접(Melee), 원거리(Caster), 공성=대포(Siege)
Red와 Blue 색상
mesh와 애니메이션을 동작하는 Rig
Animator 컴포넌트, Animation Controller(걷기, 공격, 사망 총 세가지 동작 내장)

1.2, 수정 사항
미니언이 이제 하나의 Mesh로 동작합니다. 팔, 무기, 머리 등등이 전부 하나의 Mesh이자 Object입니다.
미니언이 Animation을 행할 때 형체가 분해되거나 바닥을 헤엄치는 참극을 막았습니다.

1.3, 유의사항
해당 Asset을 import받으면 ~Minion이라는 폴더 내에 Prefab가 있습니다. 그걸 사용해주세요.

texture문제 때문에 각각 별도의 Prefab를 사용해주세요.
ex) 파란 근접 미니언(Melee Minion Blue)에게 붉은 근접 미니언의 texture를 입히지 마세요.
	기능상에 문제는 없지만 외관상에 약간의 문제가 생깁니다.
-
2, Y-bot(21 10 22 버전)

2.1, 구성
Mixamo의 Y-bot 모델 기반 Prefab
일체형 mesh와 애니메이션을 동작하는 Rig
Animator 컴포넌트, Animation Controller(10개가 넘는 동작들 내장)

-
+ 3, 지형 지물(21 10 27 버전)

3.1, 구성
20여개의 지형
롤의 협곡을 따온 구조
5개 정도의 레드/블루 진영 구조물 + 정글 오브젝트 지형 + 메인 오브젝트(바론/드레곤) 지형

3.2, 수정 사항
너무 작아서 크기를 키웠습니다. 너무 큰 것 같지만...

--